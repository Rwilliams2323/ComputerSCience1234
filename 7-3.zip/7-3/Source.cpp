#include <iostream>
#include <fstream>
#include <map>
#include <string>

using namespace std;

// Function to read data from file and fill the map with item frequencies
map<string, int> readDataFromFile(const string& filename) {
    ifstream file(filename);
    map<string, int> itemFrequencies;
    string item;

    while (file >> item) {
        itemFrequencies[item]++;
    }

    file.close();
    return itemFrequencies;
}

// Function to print the menu options
void printMenu() {
    cout << "\nMenu Options:\n"
        << "1. Search for an item\n"
        << "2. Print all items and frequencies\n"
        << "3. Print histogram of items\n"
        << "4. Exit\n"
        << "Enter your choice: ";
}

// Function to search for an item and print its frequency
void searchItem(const map<string, int>& itemFrequencies) {
    string item;
    cout << "Enter an item name: ";
    cin >> item;

    auto it = itemFrequencies.find(item);
    if (it != itemFrequencies.end()) {
        cout << item << " was purchased " << it->second << " times.\n";
    }
    else {
        cout << "Item not found.\n";
    }
}

// Function to print all items with their frequencies
void printAllItems(const map<string, int>& itemFrequencies) {
    for (const auto& pair : itemFrequencies) {
        cout << pair.first << " " << pair.second << endl;
    }
}

// Function to print a histogram of the item frequencies
void printHistogram(const map<string, int>& itemFrequencies) {
    for (const auto& pair : itemFrequencies) {
        cout << pair.first << " ";
        for (int i = 0; i < pair.second; ++i) {
            cout << "*";
        }
        cout << endl;
    }
}

int main() {
    const string filename = "CS210_Project_Three_Input_File.txt";
    auto itemFrequencies = readDataFromFile(filename);
    int choice;

    do {
        printMenu();
        cin >> choice;

        switch (choice) {
        case 1:
            searchItem(itemFrequencies);
            break;
        case 2:
            printAllItems(itemFrequencies);
            break;
        case 3:
            printHistogram(itemFrequencies);
            break;
        case 4:
            cout << "Exiting program.\n";
            break;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 4);

    return 0;
}